const range = (s, e) => Array.from('x'.repeat(e - s), (_, i) => s + i);

export default range